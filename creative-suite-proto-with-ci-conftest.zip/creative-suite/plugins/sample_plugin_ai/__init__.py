# sample ai plugin package
